package POO.AC3;

public class Vilao extends Personagem {
    public int tempoDePrisao;

    public Vilao(String nome, String nomeVidaReal, int tempoDePrisao) {
        super(nome, nomeVidaReal);
        this.tempoDePrisao = tempoDePrisao;
    }

}
